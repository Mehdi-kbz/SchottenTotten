package com.schottenTotten.model;

public enum Variante {
    STANDARD,    // Variante standard sans cartes spéciales
    TACTIQUE     // Variante tactique avec cartes spéciales
}
